package fr.univ.nantes.iut.Api;

import java.util.List;

public interface Repo<T>  {

	List<RecordEvt> getLesEvenements();
	List<RecordRest> getLesRestaurants();
}
