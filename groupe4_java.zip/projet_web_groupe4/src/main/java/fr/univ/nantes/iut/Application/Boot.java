/**
 * 
 */
package fr.univ.nantes.iut.Application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import fr.univ.nantes.iut.Api.SoireeRepository;

@SpringBootApplication
@EnableMongoRepositories(basePackageClasses = SoireeRepository.class)
public class Boot extends SpringBootServletInitializer {
	public static void main(String[] args) {
		SpringApplication.run(ServiceApp.class, args);
	}		
}
