/**
 * 
 */
package fr.univ.nantes.iut.Application;

/**
 * @author e187417p
 *
 */
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import fr.univ.nantes.iut.Api.Factory;
import fr.univ.nantes.iut.Api.Repo;
import fr.univ.nantes.iut.Domaine.Service;
import fr.univ.nantes.iut.Domaine.SoireeService;
import fr.univ.nantes.iut.Infra.FactoryImp;
import fr.univ.nantes.iut.Infra.RepoImp;


@Configuration
public class Config {
 
    @Bean
    public Service getService() {
        return new Service();
    }
   
    @Bean
    public Factory getFactory() {
        return new FactoryImp();
    }
    
    @Bean
    public Repo getRepo() {
    	return new RepoImp();
    }
    
    @Bean 
    public SoireeService getSoireeService() {
    	return new SoireeService();
    }
}